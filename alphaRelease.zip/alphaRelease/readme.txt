Bubblegum Bandit Alpha Prototype

Controls
AD - move left/right
Space/W - flip gravity
Mouse position - Aim gum
Left click mouse - Shoot gum in aim direction
1 - Activate debug mode
Left shift - toggle minimap
R - reset
9 - previous level
0 - next level